<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     �Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_themes/e107v4a/languages/English.php,v $
|     $Revision: 1.5 $
|     $Date: 2005/03/21 10:50:01 $
|     $Author: stevedunstan $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "Read/Post Comment: ");
define("LAN_THEME_2", "Comments are turned off for this item");
define("LAN_THEME_3", "Read the rest...");
define("LAN_THEME_4", "Posted by");
define("LAN_THEME_5", "on");
define("LAN_THEME_6", "This Template is Created by <a href='http://www.naja7host.com' rel='external'> Naja7host Sarl </a> , <a href='http://www.naja7host.com' rel='external'> Hosting </a> & Creation of <a href='http://www.naja7host.com' rel='external'> Websites </a> .");

define("LAN_THEME_7", "Index");
define("LAN_THEME_8", "Who Are ?");
define("LAN_THEME_9", "Sitemap");
define("LAN_THEME_10", "RSS");
define("LAN_THEME_11", "Contact Us");
define("LAN_THEME_12", "Shortlink for the News");
define("LAN_THEME_13", "News Title");
define("LAN_THEME_14", "Latest News");
// define("LAN_THEME_15", "24 Hour");
define("LAN_THEME_15", "More ... ");
// define("LAN_THEME_16", "Today's News");
define("LAN_THEME_16", "No News Entry Yet");
define("LAN_THEME_17", "Follow us on Twitter");
define("LAN_THEME_18", "Follow us on Facebook");
define("LAN_THEME_19", "Follow us on Youtube");
define("LAN_THEME_20", "Follow us on Google+");
define("LAN_THEME_21", "Follow us on linkedin");
define("LAN_THEME_22", "Follow us on github");
define("LAN_THEME_23", "Follow us on flickr");
define("LAN_THEME_24", "Follow us on instagram");
define("LAN_THEME_25", "Search Anything ?");
define("LAN_THEME_26", "No news in this category");
define("LAN_THEME_27", "newsletter");
define("LAN_THEME_28", "Subscribe in our newsletter in Feedburner)");
define("LAN_THEME_29", "your Email ... ");
define("LAN_THEME_30", "Subscribe ");
define("LAN_THEME_31", " Read  ");
define("LAN_THEME_32", " time  ");
define("LAN_THEME_33", " More  +   ");
define("LAN_THEME_34", " Ads ");
define("LAN_THEME_35", "24 Hour");
define("LAN_THEME_36", "Comments : ");
define("LAN_THEME_37", "puplish news : ");
define("LAN_THEME_38", "Shortlink For this item  ");

define("LAN_VIDEO_SHOW", "View Times");

define("ADD_COMMENT", "Add Comment");
define("ADD_COMMENT_HEADER", "Visitor Comments");
define("ADD_COMMENT_AUTHOR", "Your name *");
define("ADD_COMMENT_SUBJECT", "Subject");
define("ADD_COMMENT_BODY", "Comment *");
define("ADD_COMMENT_CAPTCHA", "Captcha");
define("ADD_COMMENT_BUTTON", "Add Comment");
?>
