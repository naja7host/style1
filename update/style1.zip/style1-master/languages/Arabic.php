<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_NAME", "");
define("LAN_THEME_1", "إفرأ/أضف تعليق : ");
define("LAN_THEME_2", "تم إلغاء التعليقات لهذا الخبر");
define("LAN_THEME_3", "(التفاصيل ...)");
define("LAN_THEME_4", "كاتب المقال ");
define("LAN_THEME_5", "نشر الخبر في");
define("LAN_THEME_6", "الموقع من تطوير و تصميم <a href='http://www.naja7host.com' rel='external'> شركة النجاح هوست </a> ، <a href='http://www.naja7host.com' rel='external'>استضافة</a> و تطوير <a href='http://www.naja7host.com' rel='external'> المواقع </a> .");
define("LAN_THEME_7", "الرئيسية");
define("LAN_THEME_8", "من نحن");
define("LAN_THEME_9", "خريطة الموقع");
define("LAN_THEME_10", "تغذيات RSS");
define("LAN_THEME_11", "اتصل بنا");
define("LAN_THEME_12", "رابط مختر للخبر تجده هنا ");
define("LAN_THEME_13", "عنوان الخبر");
define("LAN_THEME_14", "آخر الأخبار");
// define("LAN_THEME_15", "24 ساعة");
define("LAN_THEME_15", "المزيد ... ");
// define("LAN_THEME_16", "أخبار اليوم");
define("LAN_THEME_16", "لم  يتم نشر اي خبر بعد");
define("LAN_THEME_17", "تابعنا على تويتر");
define("LAN_THEME_18", "انضم الينا على فيسبوك");
define("LAN_THEME_19", "تابعنا على اليوتيب");
define("LAN_THEME_20", "تابعنا على جووجل بلوس");
define("LAN_THEME_21", "تابعنا على linkedin");
define("LAN_THEME_22", "تابعنا على github");
define("LAN_THEME_23", "تابعنا على flickr");
define("LAN_THEME_24", "تابعنا على instagram");
define("LAN_THEME_25", "هل تبحث عن شيئ ؟");
define("LAN_THEME_26", "لا يوجد أي خبر في هذا التصنيف");
define("LAN_THEME_27", "النشرة الإخبارية");
define("LAN_THEME_28", "اشترك معنا في نشرة الموقع الأسبوعية لتصلك بالبريد (الخدمة عن طريق Feedburner)");
define("LAN_THEME_29", "البريد الإلكتروني ... ");
define("LAN_THEME_30", "اشتراك ");
define("LAN_THEME_31", " مقروء  ");
define("LAN_THEME_32", " مرة  ");
define("LAN_THEME_33", " + المزيد من   ");
define("LAN_THEME_34", " إعلانات ");
define("LAN_THEME_35", "24 ساعة");
define("LAN_THEME_36", "عدد التعليقات : ");
define("LAN_THEME_37", "نشر الخبر  : ");
define("LAN_THEME_38", "رابط مختصر للمقالة تجده هنا  ");

define("LAN_VIDEO_SHOW", "عدد المشاهدات");

define("ADD_COMMENT", "أضف تعليقك");
define("ADD_COMMENT_HEADER", "تعليقات الزوار");
define("ADD_COMMENT_AUTHOR", "اسم كاتب التعليق *");
define("ADD_COMMENT_SUBJECT", "عنوان التعليق");
define("ADD_COMMENT_BODY", "التعليق *");
define("ADD_COMMENT_CAPTCHA", "أكتب الرقم الذي تراه امامك");
define("ADD_COMMENT_BUTTON", "أرسل التعليق");

?>
